/* Mon Chauffeur Lyonnais — scripts communs (menu mobile) */
(function () {
  document.documentElement.classList.add('js');
  var entete = document.querySelector('.entete');
  var bouton = document.querySelector('.btn-menu');
  if (!entete || !bouton) return;
  bouton.addEventListener('click', function () {
    var ouvert = entete.classList.toggle('est-ouvert');
    bouton.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
  });
  entete.querySelectorAll('.nav a').forEach(function (lien) {
    lien.addEventListener('click', function () {
      entete.classList.remove('est-ouvert');
      bouton.setAttribute('aria-expanded', 'false');
    });
  });
})();
