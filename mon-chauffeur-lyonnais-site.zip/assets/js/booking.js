/* ==========================================================================
   Mon Chauffeur Lyonnais — tunnel de réservation (FR / EN)
   Site statique : l'envoi passe par un service de formulaire (Formspree,
   Web3Forms…) renseigné dans l'attribut action du <form>. Tant qu'il n'est
   pas configuré, le client envoie sa demande par WhatsApp ou par e-mail.
   ========================================================================== */
(function () {
  'use strict';

  /* ---------- Réglages à compléter ---------- */
  var CONFIG = {
    whatsapp: '33XXXXXXXXX',          // numéro au format international, sans + ni espaces
    email: '[E-MAIL]',
    // Prix « à partir de » par destination (laisser null pour afficher un emplacement)
    prix: { 'aeroport': 70, 'part-dieu': 45, 'perrache': 45, 'eurexpo': null },
    prixMiseADisposition: { 'heure': null, 'demi-journee': null, 'journee': null },
    // Liens de paiement Stripe (Payment Links), facultatifs, par destination
    liensPaiement: { 'aeroport': '', 'part-dieu': '', 'perrache': '', 'eurexpo': '' }
  };

  var LANG = (document.documentElement.lang || 'fr').slice(0, 2);
  var T = {
    fr: {
      transfert: 'Transfert', mad: 'Mise à disposition',
      destination: 'Destination', duree: 'Durée',
      aeroport: 'Aéroport Saint-Exupéry', 'part-dieu': 'Gare Part-Dieu', perrache: 'Gare Perrache',
      eurexpo: 'Eurexpo', 'longue-distance': 'Longue distance ou autre',
      heure: 'À l’heure', 'demi-journee': 'Demi-journée', journee: 'Journée',
      cb: 'Carte bancaire en ligne', tpe: 'Carte à bord', facture: 'Facture mensuelle',
      numeroVol: 'Numéro de vol', numeroTrain: 'Numéro de train',
      devis: 'Devis sous 2 h', tarifFixe: 'Tarif fixe garanti', surDevis: 'Sur devis',
      noteFixe: 'À partir de ce montant depuis Lyon centre. Je vous confirme le tarif exact, qui ne changera plus.',
      noteDevis: 'Je vous envoie un tarif fixe personnalisé sous 2 h.',
      parHeure: ' / heure',
      attenteAeroport: '45 min d’attente incluses, vol suivi',
      attente: '15 min d’attente incluses',
      suivant: 'Continuer', paiement: 'Choisir le paiement',
      confirmer: 'Envoyer ma réservation', envoyerDevis: 'Envoyer ma demande de devis',
      envoi: 'Envoi en cours…',
      requis: 'Ce champ est nécessaire.', emailInvalide: 'Saisissez une adresse e-mail valide.',
      cgv: 'Merci d’accepter les conditions générales de vente.',
      echec: 'L’envoi n’a pas abouti. Envoyez votre demande par WhatsApp ou par e-mail ci-dessous.',
      titreOk: 'Votre demande de réservation est envoyée.',
      titreDevisOk: 'Votre demande de devis est envoyée.',
      texteOk: 'Je vous confirme personnellement votre réservation par e-mail ou WhatsApp. La veille du trajet, je vous rappelle l’heure et le point de rendez-vous.',
      texteDevisOk: 'Je reviens vers vous personnellement sous 2 h avec un tarif fixe.',
      titreManuel: 'Dernière étape : envoyez votre demande.',
      texteManuel: 'Choisissez votre canal : votre récapitulatif est déjà rédigé.',
      sujet: 'Demande de réservation', passagers: 'Passagers', bagages: 'Bagages',
      siege: 'Siège enfant', oui: 'oui', message: 'Message', nom: 'Nom', tel: 'Téléphone',
      societe: 'Société', depart: 'Départ', arrivee: 'Arrivée', date: 'Date', paiementL: 'Paiement',
      numero: 'N° vol/train', prestation: 'Prestation', tarif: 'Tarif indicatif',
      prixVide: '[PRIX] €'
    },
    en: {
      transfert: 'Transfer', mad: 'Chauffeur by the hour',
      destination: 'Destination', duree: 'Duration',
      aeroport: 'Saint-Exupéry Airport', 'part-dieu': 'Part-Dieu Station', perrache: 'Perrache Station',
      eurexpo: 'Eurexpo', 'longue-distance': 'Long distance or other',
      heure: 'Hourly', 'demi-journee': 'Half day', journee: 'Full day',
      cb: 'Card payment online', tpe: 'Card on board', facture: 'Monthly invoice',
      numeroVol: 'Flight number', numeroTrain: 'Train number',
      devis: 'Quote within 2 hours', tarifFixe: 'Guaranteed fixed fare', surDevis: 'On quotation',
      noteFixe: 'Starting fare from central Lyon. I will confirm your exact fare, which will not change.',
      noteDevis: 'I will send you a personalised fixed fare within 2 hours.',
      parHeure: ' / hour',
      attenteAeroport: '45 min waiting time included, flight tracked',
      attente: '15 min waiting time included',
      suivant: 'Continue', paiement: 'Choose payment',
      confirmer: 'Send my booking', envoyerDevis: 'Send my quote request',
      envoi: 'Sending…',
      requis: 'This field is required.', emailInvalide: 'Please enter a valid email address.',
      cgv: 'Please accept the terms and conditions.',
      echec: 'Your request could not be sent. Please send it via WhatsApp or email below.',
      titreOk: 'Your booking request has been sent.',
      titreDevisOk: 'Your quote request has been sent.',
      texteOk: 'I will personally confirm your booking by email or WhatsApp. The day before your journey, I will remind you of the time and meeting point.',
      texteDevisOk: 'I will reply personally within 2 hours with a fixed fare.',
      titreManuel: 'Final step: send your request.',
      texteManuel: 'Choose how to send it: your summary is already written.',
      sujet: 'Booking request', passagers: 'Passengers', bagages: 'Luggage',
      siege: 'Child seat', oui: 'yes', message: 'Message', nom: 'Name', tel: 'Phone',
      societe: 'Company', depart: 'From', arrivee: 'To', date: 'Date', paiementL: 'Payment',
      numero: 'Flight/train no.', prestation: 'Service', tarif: 'Indicative fare',
      prixVide: '€[PRICE]'
    }
  }[LANG === 'en' ? 'en' : 'fr'];

  var form = document.getElementById('form-resa');
  if (!form) return;
  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  var etapes = $$('.etape', form);
  var indicateurs = $$('.etapes li');
  var btnSuivant = $('#btn-suivant');
  var btnPrecedent = $('#btn-precedent');
  var confirmation = $('#confirmation');
  var etape = 1;

  /* ---------- Utilitaires ---------- */
  function valeur(nom) {
    var el = form.elements[nom];
    if (!el) return '';
    if (el.length !== undefined && !el.tagName) {   // groupe de boutons radio
      var coche = $$('input[name="' + nom + '"]:checked', form)[0];
      return coche ? coche.value : '';
    }
    if (el.type === 'checkbox') return el.checked;
    return (el.value || '').trim();
  }
  function cocher(nom, val) {
    var r = $('input[name="' + nom + '"][value="' + val + '"]', form);
    if (r) r.checked = true;
  }
  function formatPrix(n) {
    if (n === null || n === undefined) return T.prixVide;
    return LANG === 'en' ? '€' + n : n + ' €';
  }
  function afficher(el, visible) { if (el) el.hidden = !visible; }

  /* ---------- État dérivé ---------- */
  function etat() {
    var prestation = valeur('prestation') || 'transfert';
    var destination = valeur('destination') || 'aeroport';
    var duree = valeur('duree') || 'demi-journee';
    var transfert = prestation === 'transfert';
    var devis = transfert && destination === 'longue-distance';
    var prix = null;
    if (transfert && !devis) prix = CONFIG.prix[destination];
    if (!transfert) prix = CONFIG.prixMiseADisposition[duree];
    return {
      prestation: prestation, destination: destination, duree: duree,
      transfert: transfert, devis: devis, prix: prix,
      numero: transfert ? (destination === 'aeroport' ? 'vol' : (destination === 'part-dieu' || destination === 'perrache' ? 'train' : '')) : ''
    };
  }

  /* ---------- Mise à jour de l'interface ---------- */
  function majInterface() {
    var e = etat();
    afficher($('#bloc-destination'), e.transfert);
    afficher($('#bloc-duree'), !e.transfert);
    afficher($('#champ-arrivee'), e.devis);
    $('#arrivee').required = e.devis;
    afficher($('#champ-numero'), !!e.numero);
    afficher($('#note-suivi'), !!e.numero);
    $('#libelle-numero').textContent = e.numero === 'vol' ? T.numeroVol : T.numeroTrain;
    $('#numero').placeholder = e.numero === 'vol' ? 'AF 7643' : 'TGV 6611';

    // Encart prix (étape 3)
    $('#prix-etiquette').textContent = e.devis ? T.surDevis : T.tarifFixe;
    $('#prix-note').textContent = e.devis ? T.noteDevis : T.noteFixe;
    var texteprix = e.devis ? T.devis : formatPrix(e.prix) + (!e.transfert && e.duree === 'heure' ? T.parHeure : '');
    $('#prix-montant').textContent = texteprix;

    // Paiement (étape 4)
    afficher($('#bloc-paiement'), !e.devis);
    afficher($('#note-devis'), e.devis);

    // Récapitulatif
    $('#recap-prestation').textContent = e.transfert ? T.transfert : T.mad;
    $('#recap-cle').textContent = e.transfert ? T.destination : T.duree;
    $('#recap-choix').textContent = e.transfert ? T[e.destination] : T[e.duree];
    var d = valeur('date'), h = valeur('heure');
    $('#recap-date').textContent = d ? formatDate(d) + (h ? ' · ' + h : '') : '—';
    $('#recap-passagers').textContent = valeur('passagers') || '1';
    $('#recap-prix').textContent = texteprix;
    $('#recap-attente').textContent = (e.transfert && e.destination === 'aeroport') ? T.attenteAeroport : T.attente;

    // Bouton principal
    btnSuivant.textContent = etape === 4 ? (e.devis ? T.envoyerDevis : T.confirmer) : (etape === 3 && !e.devis ? T.paiement : T.suivant);
  }

  function formatDate(iso) {
    var p = iso.split('-');
    if (p.length !== 3) return iso;
    var dt = new Date(+p[0], +p[1] - 1, +p[2]);
    try {
      return dt.toLocaleDateString(LANG === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
    } catch (err) { return iso; }
  }

  /* ---------- Navigation entre étapes ---------- */
  function allerA(n) {
    etape = n;
    etapes.forEach(function (fs, i) { fs.hidden = (i + 1) !== n; });
    indicateurs.forEach(function (li, i) {
      var k = i + 1;
      li.classList.toggle('est-faite', k < n);
      if (k === n) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
    });
    afficher(btnPrecedent, n > 1);
    majInterface();
    var legende = $('legend', etapes[n - 1]);
    if (legende) { legende.setAttribute('tabindex', '-1'); legende.focus({ preventScroll: true }); }
    var haut = form.getBoundingClientRect().top + window.pageYOffset - 120;
    if (window.pageYOffset > haut) window.scrollTo(0, haut);
  }

  /* ---------- Validation ---------- */
  function messageErreur(champ, texte) {
    var conteneur = champ.closest('.champ, .case') || champ.parentNode;
    var p = $('.erreur', conteneur);
    if (!p) {
      p = document.createElement('p');
      p.className = 'erreur';
      p.id = 'err-' + (champ.id || champ.name);
      conteneur.appendChild(p);
    }
    p.textContent = texte || '';
    if (texte) {
      champ.setAttribute('aria-invalid', 'true');
      champ.setAttribute('aria-describedby', p.id);
    } else {
      champ.removeAttribute('aria-invalid');
    }
  }

  function valider(n) {
    var fs = etapes[n - 1];
    var premier = null;
    $$('input, select, textarea', fs).forEach(function (champ) {
      var masque = champ.closest('[hidden]');
      if ((masque && masque !== fs) || champ.type === 'radio' || champ.type === 'hidden') return;
      var texte = '';
      if (champ.required) {
        if (champ.type === 'checkbox' && !champ.checked) texte = T.cgv;
        else if (champ.type !== 'checkbox' && !champ.value.trim()) texte = T.requis;
      }
      if (!texte && champ.type === 'email' && champ.value && !champ.checkValidity()) texte = T.emailInvalide;
      messageErreur(champ, texte);
      if (texte && !premier) premier = champ;
    });
    if (premier) premier.focus();
    return !premier;
  }

  form.addEventListener('input', function (ev) {
    if (ev.target.getAttribute('aria-invalid') === 'true') messageErreur(ev.target, '');
  });
  form.addEventListener('change', function (ev) {
    if (ev.target.type === 'checkbox' && ev.target.getAttribute('aria-invalid') === 'true') messageErreur(ev.target, '');
    majInterface();
  });

  /* ---------- Compteur de passagers (1 à 3) ---------- */
  var champPassagers = $('#passagers');
  var affichagePassagers = $('#affichage-passagers');
  function majPassagers(delta) {
    var n = Math.min(3, Math.max(1, (parseInt(champPassagers.value, 10) || 1) + delta));
    champPassagers.value = n;
    affichagePassagers.textContent = n;
    $('#moins').disabled = false;
    majInterface();
  }
  $('#moins').addEventListener('click', function () { majPassagers(-1); });
  $('#plus').addEventListener('click', function () { majPassagers(1); });

  /* ---------- Récapitulatif texte (WhatsApp, e-mail, service de formulaire) ---------- */
  function resume() {
    var e = etat();
    var lignes = [
      T.sujet + ' · Mon Chauffeur Lyonnais',
      T.prestation + ' : ' + (e.transfert ? T.transfert : T.mad),
      (e.transfert ? T.destination : T.duree) + ' : ' + (e.transfert ? T[e.destination] : T[e.duree]),
      T.depart + ' : ' + valeur('depart')
    ];
    if (e.devis) lignes.push(T.arrivee + ' : ' + valeur('arrivee'));
    lignes.push(T.date + ' : ' + valeur('date') + ' ' + valeur('heure'));
    if (e.numero && valeur('numero')) lignes.push(T.numero + ' : ' + valeur('numero'));
    lignes.push(T.passagers + ' : ' + (valeur('passagers') || '1'));
    lignes.push(T.bagages + ' : ' + valeur('bagages'));
    if (valeur('siege_enfant')) lignes.push(T.siege + ' : ' + T.oui);
    if (valeur('message')) lignes.push(T.message + ' : ' + valeur('message'));
    lignes.push(T.tarif + ' : ' + (e.devis ? T.devis : formatPrix(e.prix)));
    if (!e.devis) lignes.push(T.paiementL + ' : ' + T[valeur('paiement') || 'cb']);
    lignes.push('—');
    lignes.push(T.nom + ' : ' + valeur('nom'));
    lignes.push(T.tel + ' : ' + valeur('telephone'));
    lignes.push('E-mail : ' + valeur('email'));
    if (valeur('societe')) lignes.push(T.societe + ' : ' + valeur('societe'));
    return lignes.join('\n');
  }

  function afficherConfirmation(mode) {
    var e = etat();
    var texte = resume();
    $('#lien-whatsapp').href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(texte);
    $('#lien-email').href = 'mailto:' + CONFIG.email + '?subject=' + encodeURIComponent(T.sujet) + '&body=' + encodeURIComponent(texte);
    var lienPaiement = (!e.devis && valeur('paiement') === 'cb') ? CONFIG.liensPaiement[e.destination] : '';
    if (lienPaiement && mode === 'ok') { $('#lien-paiement').href = lienPaiement; afficher($('#lien-paiement'), true); }

    if (mode === 'ok') {
      $('#confirmation-titre').textContent = e.devis ? T.titreDevisOk : T.titreOk;
      $('#confirmation-texte').textContent = e.devis ? T.texteDevisOk : T.texteOk;
    } else {
      $('#confirmation-titre').textContent = T.titreManuel;
      $('#confirmation-texte').textContent = mode === 'echec' ? T.echec : T.texteManuel;
    }
    etapes.forEach(function (fs) { fs.hidden = true; });
    afficher($('.nav-etapes'), false);
    indicateurs.forEach(function (li) { li.classList.add('est-faite'); li.removeAttribute('aria-current'); });
    afficher(confirmation, true);
    $('#confirmation-titre').setAttribute('tabindex', '-1');
    $('#confirmation-titre').focus();
  }

  /* ---------- Envoi ---------- */
  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    for (var i = 1; i <= 4; i++) {
      if (!valider(i)) { allerA(i); valider(i); return; }
    }
    $('#champ-resume').value = resume();
    var action = form.getAttribute('action') || '';
    if (!action || action.indexOf('VOTRE_ID') !== -1) { afficherConfirmation('manuel'); return; }

    btnSuivant.disabled = true;
    btnSuivant.textContent = T.envoi;
    fetch(action, { method: 'POST', body: new FormData(form), headers: { 'Accept': 'application/json' } })
      .then(function (r) { afficherConfirmation(r.ok ? 'ok' : 'echec'); })
      .catch(function () { afficherConfirmation('echec'); })
      .then(function () { btnSuivant.disabled = false; });
  });

  btnSuivant.addEventListener('click', function () {
    if (etape < 4) { if (valider(etape)) allerA(etape + 1); }
    else if (typeof form.requestSubmit === 'function') form.requestSubmit();
    else form.dispatchEvent(new Event('submit', { cancelable: true }));
  });
  btnPrecedent.addEventListener('click', function () { if (etape > 1) allerA(etape - 1); });

  /* ---------- Préremplissage depuis l'URL (cartes et formulaire de l'accueil) ---------- */
  function prefill() {
    var q = new URLSearchParams(window.location.search);
    var dest = q.get('destination');
    var arrivee = (q.get('arrivee') || '').trim();
    if (q.get('prestation') === 'mise-a-disposition') cocher('prestation', 'mise-a-disposition');
    if (!dest && arrivee) {
      var a = arrivee.toLowerCase();
      if (/a[ée]roport|airport|saint[- ]ex|lys/.test(a)) dest = 'aeroport';
      else if (/part[- ]?dieu/.test(a)) dest = 'part-dieu';
      else if (/perrache/.test(a)) dest = 'perrache';
      else if (/eurexpo/.test(a)) dest = 'eurexpo';
      else dest = 'longue-distance';
    }
    if (dest && $('input[name="destination"][value="' + dest + '"]', form)) cocher('destination', dest);
    if (dest === 'longue-distance' && arrivee) $('#arrivee').value = arrivee;
    ['depart', 'date', 'heure'].forEach(function (k) {
      var v = q.get(k);
      if (v && form.elements[k]) form.elements[k].value = v;
    });
  }

  /* ---------- Initialisation ---------- */
  var aujourdhui = new Date();
  var iso = aujourdhui.getFullYear() + '-' + String(aujourdhui.getMonth() + 1).padStart(2, '0') + '-' + String(aujourdhui.getDate()).padStart(2, '0');
  $('#date').min = iso;
  $$('.js-seul').forEach(function (el) { el.hidden = false; });
  prefill();
  allerA(1);
  // Pas de mise au point automatique au chargement
  if (document.activeElement && document.activeElement.tagName === 'LEGEND') document.activeElement.blur();
})();
